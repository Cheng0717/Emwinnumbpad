/*
*********************************************************************************************************
*
*	ģ������ : ��װϵͳ������
*	�ļ����� : Filling system.c
*	��    �� : V1.0
*	˵    �� : ��������
*              1. ���н���֧�ְ�������
*              2. ����Setting�����ɽ����װϵͳ�����趨ҳ��
*			   3. ����Stop��������ͣ��ǰ����
*			   4. ����Restart��������������
*	�޸ļ�¼ :

*	�� �� �� :V1.0     
*	��    �� : 2020��10��11��14:59:11        
*	��    �� : Cheng         
*	˵    �� :
*                1. STemWin�汾V5.28
*				 
*                 
*                 
*

*********************************************************************************************************
*/
#include "DIALOG.h"

/*********************************************************************
*
*       �궨��
*
**********************************************************************
*/
#define ID_FRAMEWIN_0        (GUI_ID_USER + 0x00)
#define ID_BUTTON_0        (GUI_ID_USER + 0x00)
#define ID_BUTTON_1        (GUI_ID_USER + 0x01)
#define ID_BUTTON_2        (GUI_ID_USER + 0x02)
#define ID_TEXT_0        (GUI_ID_USER + 0x04)
#define ID_TEXT_1        (GUI_ID_USER + 0x05)
#define ID_TEXT_2        (GUI_ID_USER + 0x06)
#define ID_TEXT_3        (GUI_ID_USER + 0x07)
#define ID_TEXT_4        (GUI_ID_USER + 0x08)
#define ID_TEXT_5        (GUI_ID_USER + 0x09)

#define ID_EDIT_0        (GUI_ID_USER + 0x02)
#define ID_ICONVIEW_0        (GUI_ID_USER + 0x04)

#define ID_WINDOW_0      (GUI_ID_USER + 0x00)
/*#define ID_BUTTON_0      (GUI_ID_USER + 0x01)//1
#define ID_BUTTON_1      (GUI_ID_USER + 0x02)
#define ID_BUTTON_2      (GUI_ID_USER + 0x03)*/
#define ID_BUTTON_3      (GUI_ID_USER + 0x03)
#define ID_BUTTON_4      (GUI_ID_USER + 0x04)
#define ID_BUTTON_5      (GUI_ID_USER + 0x05)
#define ID_BUTTON_6      (GUI_ID_USER + 0x06)
#define ID_BUTTON_7      (GUI_ID_USER + 0x07)
#define ID_BUTTON_8      (GUI_ID_USER + 0x08)
#define ID_BUTTON_9      (GUI_ID_USER + 0x09)//0
#define ID_BUTTON_10      (GUI_ID_USER + 0x0A)//esc 
#define ID_BUTTON_11      (GUI_ID_USER + 0x0B)//del 

/*********************************************************************
*				�ⲿ����
**********************************************************************
*/
static int _aKey[] = { GUI_KEY_BACKSPACE, };
GUI_BITMAP system1_tab[4];			//����λͼ���飬4������4��Ƥ��

extern GUI_CONST_STORAGE GUI_BITMAP bmsetting;	//���ð���ͼ��
extern GUI_CONST_STORAGE GUI_BITMAP bmstop;		//��ͣ����ͼ��
extern GUI_CONST_STORAGE GUI_BITMAP bmcontinue;	//��������ͼ��
extern GUI_CONST_STORAGE GUI_BITMAP bmback;		//���ذ���ͼ��
		

extern GUI_CONST_STORAGE GUI_BITMAP bmbottle;//ƿ��ͼ��

/*
*************************************************************************************************
*   ��������
*************************************************************************************************
*/
static void _cbDialog1(WM_MESSAGE * pMsg);
static void _cbDialog2(WM_MESSAGE * pMsg);
static void _cbDialogNumPad(WM_MESSAGE * pMsg);


/********************************************************************************************
*						_aDialogCreate1
*********************************************************************************************
*/
static const GUI_WIDGET_CREATE_INFO _aDialogCreate1[] = {
	/*     �ؼ�����                   �����ı�  ���        X,Y,xSize��ySize                     */
		{ FRAMEWIN_CreateIndirect, "system", ID_FRAMEWIN_0, 0, 0, 320, 240, 0, 0x64, 0 },
		{ BUTTON_CreateIndirect, "Button", ID_BUTTON_0, 240, 0, 50, 50, 0, 0x0, 0 },
		{ TEXT_CreateIndirect, "Text", ID_TEXT_0, 240, 50, 50, 20, 0, 0x64, 0 },
		{ BUTTON_CreateIndirect, "Button", ID_BUTTON_1, 240, 70, 50, 50, 0, 0x0, 0 },
		{ TEXT_CreateIndirect, "Text", ID_TEXT_1, 242, 120, 40, 20, 0, 0x64, 0 },
		{ BUTTON_CreateIndirect, "Button", ID_BUTTON_2, 240, 140, 50, 50, 0, 0x0, 0 },
		{ TEXT_CreateIndirect, "Text", ID_TEXT_2, 240, 190, 50, 20, 0, 0x64, 0 },
		{ TEXT_CreateIndirect, "Text", ID_TEXT_3, 5, 10, 80, 20, 0, 0x64, 0 },
		{ TEXT_CreateIndirect, "Text", ID_TEXT_4, 5, 50, 150, 20, 0, 0x64, 0 },
		{ TEXT_CreateIndirect, "Text", ID_TEXT_5, 5, 100, 150, 20, 0, 0x64, 0 },

};

/****************************************************************************************************
*       _aDialogCreate2
*****************************************************************************************************
*/
static const GUI_WIDGET_CREATE_INFO _aDialogCreate2[] = {
	/*     �ؼ�����                  �����ı�  ���          X, Y,xSize ySize               */
		{ FRAMEWIN_CreateIndirect, "system2", ID_FRAMEWIN_0, 0, 0, 320, 240, 0, 0x64, 0 },
		{ BUTTON_CreateIndirect, "Button", ID_BUTTON_0, 0, 0, 80, 40, 0, 0x0, 0 },
		{ EDIT_CreateIndirect, "Edit", ID_EDIT_0, 40, 60, 40, 20, 0, 0x64, 0 },
		{ TEXT_CreateIndirect, "ml", ID_TEXT_2, 90, 60, 80, 20, 0, 0x64, 0 },
		{ ICONVIEW_CreateIndirect, "Iconview", ID_ICONVIEW_0, 10, 50, 22, 48, 0, 0x00300030, 0 },
							//0x00300030Ϊ���icon��ѡ�еĿ�0x30=48��������Ϊ�㣬ͼ���޷���ʾ
};
/*********************************************************************
*       _aDialogCreate2
*******************************************************************
*/
static const GUI_WIDGET_CREATE_INFO _aDialogNumPad[] = {
		{ WINDOW_CreateIndirect, "WindowNumpad", ID_WINDOW_0, 159, 59, 160, 180, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "1", ID_BUTTON_0, 5, 135, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "2", ID_BUTTON_1, 60, 135, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "3", ID_BUTTON_2, 115, 135, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "4", ID_BUTTON_3, 5, 90, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "5", ID_BUTTON_4, 60, 90, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "6", ID_BUTTON_5, 115, 90, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "7", ID_BUTTON_6, 5, 45, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "8", ID_BUTTON_7, 60, 45, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "9", ID_BUTTON_8, 115, 45, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "0", ID_BUTTON_9, 60, 1, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "DEL", ID_BUTTON_10, 115, 1, 40, 40, 0, 0x0, 0 },
		{ BUTTON_CreateIndirect, "OK", ID_BUTTON_11, 5, 1, 40, 40, 0, 0x0, 0 },
		// USER START (Optionally insert additional widgets)
		// USER END
};


/***********************************************************************************************
*       _cbDialog1
***********************************************************************************************
*/
static void _cbDialog1(WM_MESSAGE * pMsg) {	
	int     NCode;
	int     Id;
	int    i;
	static U8 setting = 0;
	static U8 stop = 0;
	static U8 Continue = 0;
	WM_HWIN hItem = pMsg->hWin;
	WM_HWIN BUTTON;
	
	switch (pMsg->MsgId) {
	case WM_PAINT:
		GUI_SetBkColor(GUI_WHITE);
		GUI_Clear();
		break;

	case WM_INIT_DIALOG:
		for (i = 0; i <= GUI_COUNTOF(_aDialogCreate1) - 1; i++){
			BUTTON = WM_GetDialogItem(hItem, GUI_ID_USER + i);
			BUTTON_SetFocussable(BUTTON, 0); // Set all buttons non focussable  //--------------��7��
		}
		//**********************************************************************
		// ϵͳ��ʼ��
		//********************************************************************
		hItem = pMsg->hWin;
		FRAMEWIN_SetTextAlign(hItem, GUI_TA_HCENTER | GUI_TA_VCENTER);
		FRAMEWIN_SetTextColor(hItem, 0xFFFFF);
		FRAMEWIN_SetTitleHeight(hItem, 20);
		FRAMEWIN_SetText(hItem, "Filling system");
		FRAMEWIN_SetFont(hItem, GUI_FONT_20_1);
		//**********************************************************************
		//��ʼ�� ��������  ����
		//**********************************************************************
		hItem = WM_GetDialogItem(pMsg->hWin, ID_BUTTON_0);
		BUTTON_SetBitmapEx(hItem, 0, &system1_tab[0], 0, 0);
		BUTTON_SetText(hItem, "");
		//**********************************************************************
		//��ʼ�� �ı� Setting
		//**********************************************************************
		hItem = WM_GetDialogItem(pMsg->hWin, ID_TEXT_0);
		TEXT_SetText(hItem, "Setting");
		TEXT_SetFont(hItem, GUI_FONT_13HB_1);


		//��ʼ�� ���� Stop
		hItem = WM_GetDialogItem(pMsg->hWin, ID_BUTTON_1);
		BUTTON_SetBitmapEx(hItem, 0, &system1_tab[1], 0, 0);
		BUTTON_SetText(hItem, "");
		//**********************************************************************
		// ��ʼ�� �ı� Restart
		//**********************************************************************
		hItem = WM_GetDialogItem(pMsg->hWin, ID_TEXT_1);
		TEXT_SetText(hItem, "Stop");
		TEXT_SetFont(hItem, GUI_FONT_16B_ASCII);
		//**********************************************************************
		//��ʼ�� ���� Restart
		//**********************************************************************
		hItem = WM_GetDialogItem(pMsg->hWin, ID_BUTTON_2);
		BUTTON_SetBitmapEx(hItem, 0, &system1_tab[2], 0, 0);
		BUTTON_SetText(hItem, "");
		//**********************************************************************
		// ��ʼ���ı� Restart
		//**********************************************************************
		hItem = WM_GetDialogItem(pMsg->hWin, ID_TEXT_2);
		TEXT_SetText(hItem, "Restart");
		TEXT_SetFont(hItem, GUI_FONT_13HB_1);
		//
		// Initialization of 'Text'
		//
		hItem = WM_GetDialogItem(pMsg->hWin, ID_TEXT_3);
		TEXT_SetText(hItem, "Run time:");
		TEXT_SetFont(hItem, GUI_FONT_16B_1);
		//
		// Initialization of 'Text'
		//
		hItem = WM_GetDialogItem(pMsg->hWin, ID_TEXT_4);
		TEXT_SetFont(hItem, GUI_FONT_16B_1);
		TEXT_SetText(hItem, "Total filling number:");
		//
		// Initialization of 'Text'
		//
		hItem = WM_GetDialogItem(pMsg->hWin, ID_TEXT_5);
		TEXT_SetFont(hItem, GUI_FONT_16B_1);
		TEXT_SetText(hItem, "Current filling capacity:");

		break;
	case WM_NOTIFY_PARENT:
		Id = WM_GetId(pMsg->hWinSrc);
		NCode = pMsg->Data.v;
		switch (Id) {
		case ID_BUTTON_0: // Notifications sent by 'Button'
			switch (NCode) {
			case WM_NOTIFICATION_CLICKED:
				// setting = ~setting;
				//  BUTTON_SetBitmapEx(hItem, 0, setting ? &system1_tab[0] : &system1_tab[1], 0, 0);
				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
			case WM_NOTIFICATION_RELEASED:
				GUI_EndDialog(pMsg->hWin, 0);
				GUI_CreateDialogBox(_aDialogCreate2, GUI_COUNTOF(_aDialogCreate2), _cbDialog2, WM_HBKWIN, 0, 0);
				break;
			}
			break;
		case ID_BUTTON_1: // Notifications sent by 'Button'
			switch (NCode) {
			case WM_NOTIFICATION_CLICKED:
				// stop = ~stop;
				// BUTTON_SetBitmapEx(hItem, 0, stop ? &set_tab[1] : &set_tab[0], 0, 0);

				break;
			case WM_NOTIFICATION_RELEASED:

				break;

			}
			break;
		case ID_BUTTON_2: // Notifications sent by 'Button'
			switch (NCode) {
			case WM_NOTIFICATION_CLICKED:
				// Continue = ~Continue;
				//  BUTTON_SetBitmapEx(hItem, 0, stop ? &set_tab[2] : &set_tab[1], 0, 0);

				break;
			case WM_NOTIFICATION_RELEASED:

				break;

			}
			break;

		}
		break;

	default:
		WM_DefaultProc(pMsg);
		break;
	}
}

/*********************************************************************
*
*       _cbDialog2
*/
static void _cbDialog2(WM_MESSAGE * pMsg) {
	//const void * pData;
	int     NCode;
	int     Id;
	WM_HWIN BUTTON;
	WM_HWIN		hNumPad;
	static U8 back = 0;

	WM_HWIN hItem = pMsg->hWin;
	switch (pMsg->MsgId) {
	
	case WM_PAINT:
			GUI_SetBkColor(GUI_WHITE);
			GUI_Clear();
			break;



	case WM_INIT_DIALOG:
		BUTTON = WM_GetDialogItem(hItem, ID_BUTTON_0);

		BUTTON_SetFocussable(BUTTON, 0); /* Set all buttons non focussable */ //--------------��7��
		//
		// ��ʼ�� 'system2'

		hItem = WM_GetDialogItem(pMsg->hWin, ID_ICONVIEW_0);
		ICONVIEW_SetIconAlign(hItem, ICONVIEW_IA_TOP);

		ICONVIEW_SetTextColor(hItem, ICONVIEW_CI_UNSEL, GUI_GRAY);//���ƴ���δѡ��״̬�ı�ǩ��ʹ�õ���ɫ��
		ICONVIEW_SetTextColor(hItem, ICONVIEW_CI_SEL, GUI_GREEN); //���ƴ��ڱ�ѡ��״̬�ı�ǩ��ʹ�õ���ɫ��

		ICONVIEW_SetBkColor(hItem, ICONVIEW_CI_SEL, GUI_TRANSPARENT);//���icon��С����ѡ�е���ɫΪ��ɫ��͸��
		ICONVIEW_SetBkColor(hItem, ICONVIEW_CI_BK, GUI_LIGHTGRAY);//����С���߱���Ҫʹ�õ���ɫ

		ICONVIEW_SetFrame(hItem, GUI_COORD_X, -13);//����ͼ�굽 IconView �߿��x���
		ICONVIEW_SetFrame(hItem, GUI_COORD_Y, 0);//����ͼ�굽 IconView �߿��y���
		ICONVIEW_AddBitmapItem(hItem, &bmbottle, "");//����ͼ������ұ�ע����


		hItem = pMsg->hWin;
		FRAMEWIN_SetText(hItem, "Parameter Setting");
		FRAMEWIN_SetTextColor(hItem, 0x00000000);
		FRAMEWIN_SetTextAlign(hItem, GUI_TA_HCENTER | GUI_TA_VCENTER);
		FRAMEWIN_SetFont(hItem, GUI_FONT_16B_1);
		//
		// Initialization of 'Button'
		//
		hItem = WM_GetDialogItem(pMsg->hWin, ID_BUTTON_0);
		BUTTON_SetText(hItem, "");
		BUTTON_SetBitmapEx(hItem, 0, &system1_tab[3], 0, 0);//����backƤ��λͼ����
		//BUTTON_SetBitmapEx(hItem, BUTTON_BI_UNPRESSED, &bmback, 0, 0);//����backƤ��λͼ����
		BUTTON_SetFont(hItem, GUI_FONT_16B_1);
		//
		// Initialization of 'Edit'
		//
		hItem = WM_GetDialogItem(pMsg->hWin, ID_EDIT_0);
		EDIT_SetText(hItem, "500");
		//
		// Initialization of 'Text'
		//
		hItem = WM_GetDialogItem(pMsg->hWin, ID_TEXT_2);
		TEXT_SetFont(hItem, GUI_FONT_16B_1);
		TEXT_SetText(hItem, "ml");
		// USER START (Optionally insert additional code for further widget initialization)
		// USER END
		break;
	case WM_NOTIFY_PARENT:
		Id = WM_GetId(pMsg->hWinSrc);
		NCode = pMsg->Data.v;
		switch (Id) {
		case ID_BUTTON_0: // Notifications sent by 'Button'
			switch (NCode) {
			case WM_NOTIFICATION_CLICKED:

				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
			case WM_NOTIFICATION_RELEASED:
				GUI_EndDialog(pMsg->hWin, 0);
				GUI_CreateDialogBox(_aDialogCreate1, GUI_COUNTOF(_aDialogCreate1), _cbDialog1, WM_HBKWIN, 0, 0);

				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
				// USER START (Optionally insert additional code for further notification handling)
				// USER END
			}
			break;
		case ID_EDIT_0: // Notifications sent by 'Edit'
			switch (NCode) {
			case WM_NOTIFICATION_CLICKED:
				GUI_EndDialog(pMsg->hWin, 0);
				hNumPad = GUI_CreateDialogBox(_aDialogNumPad,
					GUI_COUNTOF(_aDialogNumPad),
					_cbDialogNumPad, WM_HBKWIN, 0, 0); /* ����numpad�Ի��� */
				WM_SetStayOnTop(hNumPad, 1);
				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
			case WM_NOTIFICATION_RELEASED:
				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
			case WM_NOTIFICATION_VALUE_CHANGED:
				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
				// USER START (Optionally insert additional code for further notification handling)
				// USER END
			}
			break;
		case ID_ICONVIEW_0: // Notifications sent by 'Iconview'
			switch (NCode) {
			case WM_NOTIFICATION_CLICKED:
				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
			case WM_NOTIFICATION_RELEASED:
				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
			case WM_NOTIFICATION_MOVED_OUT:
				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
			case WM_NOTIFICATION_SCROLL_CHANGED:
				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
			case WM_NOTIFICATION_SEL_CHANGED:
				// USER START (Optionally insert code for reacting on notification message)
				// USER END
				break;
				// USER START (Optionally insert additional code for further notification handling)
				// USER END
			}
			break;
			// USER START (Optionally insert additional code for further Ids)
			// USER END
		}
		break;
		// USER START (Optionally insert additional message handling)
		// USER END
	default:
		WM_DefaultProc(pMsg);
		break;
	}
}

/*********************************************************************
*       _cbDialog3
**********************************************************************
*/

static void _cbDialogNumPad(WM_MESSAGE * pMsg) {
	unsigned i;
	int NCode;
	unsigned Id;
	int Pressed;
	int Key;
	char acBuffer[10];
	WM_HWIN BUTTON;
	WM_HWIN hItem = pMsg->hWin;

	Pressed = 0;
	switch (pMsg->MsgId) {
	case WM_INIT_DIALOG:
		for (i = 0; i <= GUI_COUNTOF(_aDialogNumPad) - 1; i++){
			BUTTON = WM_GetDialogItem(hItem, GUI_ID_USER + i);

			BUTTON_SetFocussable(BUTTON, 0); /* Set all buttons non focussable */ //--------------��7��
		}
		
		WINDOW_SetBkColor(hItem, 0x00D6D6D6);
		/*
		***********************************************
		*************��ʼ��С���̵����а�ť
		*********************************************
		*/
		for (i = 0; i <= 12; i++){
	
		hItem = WM_GetDialogItem(pMsg->hWin, GUI_ID_USER + i);
		BUTTON_SetFont(hItem, GUI_FONT_24_1);
}

		break;
	case WM_NOTIFY_PARENT:				//�ػ�����Ϣ

		Id = WM_GetId(pMsg->hWinSrc);
		NCode = pMsg->Data.v;

		switch (NCode) {

		case WM_NOTIFICATION_CLICKED:	//������ں�֪ͨ��Ϣ
			Pressed = 1;
			/*	break;*/       //���ܼ�break  
		case WM_NOTIFICATION_RELEASED:	/* �ͷŵ�ʱ�� */
			if ((Id >= GUI_ID_USER) && (Id <= (GUI_ID_USER + GUI_COUNTOF(_aDialogNumPad) - 2))) {
				int Key;
				if (Id <= GUI_ID_USER + 9) {
					char acBuffer[10];
					BUTTON_GetText(pMsg->hWinSrc, acBuffer, sizeof(acBuffer)); /*  */
					Key = acBuffer[0];
				}
				else if (Id == GUI_ID_USER + 11) {            /* OK ��ť */
					GUI_EndDialog(pMsg->hWin, 0); //���ش���
					GUI_CreateDialogBox(_aDialogCreate2, GUI_COUNTOF(_aDialogCreate2), _cbDialog2, WM_HBKWIN, 0, 0);//���´����´���
				}

				else {
					Key = _aKey[Id - GUI_ID_USER - 10];                        /* ��ȡ��ť���ı� */
				}
				GUI_SendKeyMsg(Key, Pressed);                                /* ����һ����������Ϣ�����㴰�� */
			}
			break;
			// USER START (Optionally insert additional code for further Ids)
			// USER END
		}
		break;
		// USER START (Optionally insert additional message handling)
		// USER END
	default:
		WM_DefaultProc(pMsg);
		break;
	}
}

/*********************************************************************
*
*       Public code
*
**********************************************************************
*/
/*********************************************************************
*
*       Createsystem
*/
WM_HWIN Createsystem1(void);
WM_HWIN Createsystem1(void) {
	WM_HWIN hWin;
	system1_tab[0] = bmsetting;
	system1_tab[1] = bmstop;
	system1_tab[2] = bmcontinue;
	system1_tab[3] = bmback;
	hWin = GUI_CreateDialogBox(_aDialogCreate1, GUI_COUNTOF(_aDialogCreate1), _cbDialog1, WM_HBKWIN, 0, 0);
	return hWin;
}

static void _cbDesktop(WM_MESSAGE * pMsg) {
	unsigned i;
	WM_HWIN hWin;
	system1_tab[0] = bmsetting;
	system1_tab[1] = bmstop;
	system1_tab[2] = bmcontinue;
	system1_tab[3] = bmback;

		hWin = GUI_CreateDialogBox(_aDialogCreate1, GUI_COUNTOF(_aDialogCreate1), _cbDialog1, WM_HBKWIN, 0, 0);


	
	
}
/*********************************************************************************************************
*	�� �� ��: MainTask
*	����˵��: ������
*	��    �Σ���
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void MainTask(void)
{
	GUI_Init();
	Createsystem1();//* �����Ի���
 while (1)
 {
	GUI_Delay(50);
 }
  }

/*void MainTask(void) {
	WM_HWIN hNumPad;
	system1_tab[3] = bmback;
	GUI_Init();
	WM_SetCallback(WM_HBKWIN, _cbDesktop);
	hNumPad = GUI_CreateDialogBox(_aDialogNumPad,
		GUI_COUNTOF(_aDialogNumPad),
		_cbDialogNumPad, WM_HBKWIN, 0, 0); //* ����numpad�Ի��� 
	WM_SetStayOnTop(hNumPad, 1);
	while (1) {
		      //* ִ���û��Ի��� 
		GUI_Delay(1000);
	}
}	*/
